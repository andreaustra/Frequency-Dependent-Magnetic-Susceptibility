% ************************************************************** 
% FDS_inv - Low field frequency dependent magnetic susceptibility inversion Software 
% Tested using Matlab 8.5 Release 2015a under MacOS 
% *********************************************************** 
%           AUTHORS 
% Andrea Ustra, Carlos Mendonca, Arua Leite - 2018
% andrea.ustra@iag.usp.br
% carlos.mendonca@iag.usp.br
% arualeite@gmail.com
% Universidade de Sao Paulo   
% Instituto de Astronomia, Geofisica e Ciencias Atmosfericas
% Departamento de Geofisica
% Sao Paulo - Brasil 
% ***********************************************************
% crossplot_FDS_inv.m is an auxiliary function in FDS_inv that plots
% the measured and calculated values of all sets of FDS data and returns 
% the correlation coefficient R^2 obtained by the linear regression 

whichstats={'rsquare'};
S=regstats(XO,XC,'linear',whichstats);
R2=S.rsquare;
cR=num2str(0.01*round(100*R2));

figure
plot(XO,XC,'ok'); axis square
xlabel('\chi_{measured} (SI)');
ylabel('\chi_{calculated} (SI)');

w=axis;
wi=min(w(1),w(3));
wf=max(w(2),w(4));
axis([wi wf wi wf]);w=axis;
hold on
plot([wi wf],[wi wf],':k')
hold off
dw=[w(4)-w(3)]/8;
text(w(1)+dw,w(4)-1*dw,['{R^2}=   ' num2str(cR)])
