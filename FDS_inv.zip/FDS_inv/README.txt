FDS_inv: MATLAB-Based Software for Low field frequency dependent magnetic 
susceptibility inversion 
FDS_inv is an open source package written in  MATLAB using Version 8.5 Release 2015a. 
------------------------------------------------------------------------------------- 
This program is based on the theory presented in 
Ustra, A., Mendonca, C. A., Leite, A., Jovane, L. and Trindade, R.I.F.
Quantitative interpretation of the magnetic susceptibility frequency effect
Geophysical Journal International. Doi: 10.10903/gji/ggy007.
------------------------------------------------------------------------------------- 
Acknowledgements
The authors thank Fundacao de Amparo a Pesquisa do Estado de Sao Paulo - FAPESP
(grant #2016/17767-0) and Coordenadoria de Aperfeicoamento de Pessoal de Nivel 
Superior - CAPES (PNPD program) for research funding. 
------------------------------------------------------------------------------------- 
Version 
------------------------------------------------------------------------------------- 
This FDS_inv version is 1.1
------------------------------------------------------------------------------------- 
Copyright 
-------------------------------------------------------------------------------------  
Copyright (C) 2018 Andrea Ustra, Carlos Mendonca, Arua Leite
------------------------------------------------------------------------------------- 
License 
------------------------------------------------------------------------------------- 
FDS_inv is released under the terms of the GNU GENERAL PUBLIC LICENSE. 
This program is distributed in the hope that it will be useful, but  
it is in further development. 
------------------------------------------------------------------------------------- 
Installation Procedure 
------------------------------------------------------------------------------------- 
We suggest to create a directory called 
c:\FDS_inv and unzip the all items of FDS_inv.rar file on it. 
c:\FDS_inv   folder has 9 files 
1- readme.txt 
2- data_test_FDS_inv.xlsx 
3- FDS_inv.m 
4- fobj_FDS_inv.m 
5- fwd_FDS_inv.m 
6- plot_FDS_inv.m
7- crossplot_FDS_inv.m 
8- profile_FDS_inv.m 
9- order.m 
c:\FDS_inv\Projects  user can save projects into this folder 
------------------------------------------------------------------------------------- 
- data_test_FDS_inv.xlsx is an example data file
- FDS_inv.m is the main script in FDS_inv. It loads dataset files, runs the FDS 
inversion, plots the results and stores the results in matrices
- fobj_FDS_inv.m is an auxiliary function in FDS_inv that calculates the inversion misfit 
by the Euclidean norm
- fwd_FDS_inv.m is an auxiliary function in FDS_inv that runs the forward inversion 
problem, that is, calculates FDS values using the model
- plot_FDS_inv.m is an auxiliary function in FDS_inv that plots the inversion results 
for each FDS measurement dataset (three frequencies)
- crossplot_FDS_inv.m (auxiliary function in FDS_inv that plots the measured and 
calculated values of all sets of FDS data and returns the correlation coefficient R^2 
obtained by the linear regression 
- profile_FDS_inv.m is an auxiliary function in FDS_inv that plots the measured and 
calculated values of all sets of FDS data and returns the correlation coefficient R^2 
obtained by the linear regression
- order.m is an auxiliary function in FDS_inv used to adjust the results graphic display
---
To reproduce the results in Section 3 (Figures 4 and 5), the user should first run 
this main function, inputting data in file data_test_FDS_inv.xlsx and using constraints 
set by default
------------------------------------------------------------------------------------- 
Input data format
------------------------------------------------------------------------------------- 
Input data file requires the following format
data=[sN X1 X2 X3]
where SN, X1, X2 and X3 are vectors for:
sN = Sample ID number
X1 = magnetic susceptibility measured at 976 Hz
X2 = magnetic susceptibility measured at 3904 Hz
X3 = magnetic susceptibility measured at 15616 Hz
------------------------------------------------------------------------------------- 
Contact 
------------------------------------------------------------------------------------- 
Andrea Ustra
Universidade de Sao Paulo   
Instituto de Astronomia, Geofisica e Ciencias Atmosfericas
Departamento de Geofisica
Sao Paulo - Brasil 
Tel: +55-11-30914755 Fax: +55-11-30915034
E-mail: andrea.ustra@iag.usp.br 
------- Please contact us if you have any suggestions or any problems ---------
Enjoy!