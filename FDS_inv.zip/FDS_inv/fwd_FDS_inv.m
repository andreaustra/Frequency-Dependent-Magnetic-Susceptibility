% ************************************************************** 
% FDS_inv - Low field frequency dependent magnetic susceptibility inversion Software 
% Tested using Matlab 8.5 Release 2015a under MacOS 
% *********************************************************** 
%           AUTHORS 
% Andrea Ustra, Carlos Mendonca, Arua Leite - 2018
% andrea.ustra@iag.usp.br
% carlos.mendonca@iag.usp.br
% arualeite@gmail.com
% Universidade de Sao Paulo   
% Instituto de Astronomia, Geofisica e Ciencias Atmosfericas
% Departamento de Geofisica
% Sao Paulo - Brasil 
% ***********************************************************
% fwd_FDS_inv.m is an auxiliary function in FDS_inv that runs the forward
% inversion problem, that is, calculates FDS values using the model
% proposed by Ustra et al. 2018

function Mc=fwd_FDS_inv(p)
global Dados nfreq
Xsd=p(1);
dX=p(2);
tau=p(3);
omg=2*pi;
freq=Dados(:,1);
Mc=zeros(nfreq,1);
for i=1:nfreq
    au=omg*freq(i)*tau;
    Mc(i,1)=Xsd+dX/(1+au*au);
end
return
end