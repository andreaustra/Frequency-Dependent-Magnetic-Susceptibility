% ************************************************************** 
% FDS_inv - Low field frequency dependent magnetic susceptibility inversion Software 
% Tested using Matlab 8.5 Release 2015a under MacOS 
% *********************************************************** 
%           AUTHORS 
% Andrea Ustra, Carlos Mendonca, Arua Leite - 2018
% andrea.ustra@iag.usp.br
% carlos.mendonca@iag.usp.br
% arualeite@gmail.com
% Universidade de Sao Paulo   
% Instituto de Astronomia, Geofisica e Ciencias Atmosfericas
% Departamento de Geofisica
% Sao Paulo - Brasil 
% ***********************************************************
% plot_FDS_inv.m is an auxiliary function in FDS_inv that plots the 
% inversion results for each FDS measurement dataset (three frequencies)

figure
plottools 'on'
subplot(121)
h=loglog(Dados(:,1),Dados(:,2),'ok');
set(h,'MarkerSize',8,'MarkerFaceColor','k')
xlabel('Frequency (Hz)')
ylabel('Susceptibility (SI)')
title(num2str(kDa))
axis square

hold on
w=axis;
w(3)=10^(order(min(Dados(:,2)))-0);
w(4)=10^(order(max(Dados(:,2)))+1);
nFreq=nfreq;nfreq=50;
fq=logspace(2,6)';
DaDos=Dados;
for k=1:Km
    Dados=[fq;fq];
    dc=fwd_FDS_inv(REM(1:3,k));
    loglog(fq,dc,'-k')
    fqm=1/(2*pi*REM(3,k));loglog([fqm fqm],[w(3) w(4)],'-b')
    fqm=1/(2*pi*tf);loglog([fqm fqm],[w(3) w(4)],'--k')
    fqm=1/(2*pi*ti);loglog([fqm fqm],[w(3) w(4)],'--k')
    axis(w)
end
hold off
Dados=DaDos;
nfreq=nFreq;

subplot(122)
h=plot(Dados(:,2),Mc,'-or');axis square
set(h,'MarkerSize',8,'MarkerFaceColor','y')
xlabel('Measured')
ylabel('Calculated')
w=axis;
wi=min(w(1),w(3));
wf=max(w(2),w(4));
axis([wi wf wi wf]);w=axis;
hold on
plot([wi wf],[wi wf],':k')
hold off
pc(1)=1e-8*round(pmed(1)*1e+8);
pc(2)=1e-8*round(pmed(2)*1e+8);
pc(3)=1e-8*round(pmed(3)*1e+8);
qc(1)=1e-8*round(pstd(1)*1e+8);
qc(2)=1e-8*round(pstd(2)*1e+8);
qc(3)=1e-8*round(pstd(3)*1e+8);
dw=[w(4)-w(3)]/8;
text(w(1)+dw,w(4)-1*dw,['{\chi_{hf}}=' num2str(pc(1),'%10.2e\n') '{\pm}' num2str(qc(1),'%10.2e\n')])
text(w(1)+dw,w(4)-2*dw,['\Delta\chi=' num2str(pc(2),'%10.2e\n') '{\pm}' num2str(qc(2),'%10.2e\n')])
text(w(1)+dw,w(4)-3*dw,['{\tau}=' num2str(1e6*pc(3),5) '{\pm}' num2str(1e6*qc(3),5) ' ({\mu}s)'])