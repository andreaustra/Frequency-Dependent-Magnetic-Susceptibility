% ************************************************************** 
% FDS_inv - Low field frequency dependent magnetic susceptibility inversion Software 
% Tested using Matlab 8.5 Release 2015a under MacOS 
% *********************************************************** 
%           AUTHORS 
% Andrea Ustra, Carlos Mendonca, Arua Leite - 2018
% andrea.ustra@iag.usp.br
% carlos.mendonca@iag.usp.br
% arualeite@gmail.com
% Universidade de Sao Paulo   
% Instituto de Astronomia, Geofisica e Ciencias Atmosfericas
% Departamento de Geofisica
% Sao Paulo - Brasil 
% ***********************************************************
% FDS_inv.m is the main script in the FDS_inv
% FDS_inv.m loads dataset files, runs the FDS inversion, plots the results
% and stores the results in matrices

clear;clc;
global Dados nfreq
P=input('ENTER PATH     ');addpath(P);
FN=input('ENTER FILE  ');
Da=xlsread(FN); % example: 'file.txt'
%%% data file format: 
%%% col 1: sample ID number (ex: depth)
%%% col 2: frequency 1 - in-phase susceptibility 
%%% col 3: frequency 2 - in-phase susceptibility 
%%% col 4: frequency 3 - in-phase susceptibility 
nDa=length(Da(:,1));
xlf=zeros(nDa,1);xhf=zeros(nDa,1);dx=zeros(nDa,1);LFE=zeros(nDa,1);
Z=Da(:,1);RMS=zeros(nDa,1);XT=zeros(nDa,6);

%-----------------------------INVERSION
nfreq=3;freq=[976;3904;15616];
nsol=10;
ti=input('minimum relaxation time constrain (type 0 for default)     '); % order of 1e-6;
tf=input('maximum relaxation time constrain (type 0 for default)     '); % order of 1e-4
xi=input('minimum susceptibility constrain (type 0 for default)      '); % 10% of the highest MS at F3
xf=input('maximum susceptibility constrain (type 0 for default)      '); % 110% of the lowest MS at F1

if ti==0;
    ti=0.5*1e-5;
else
end

if tf==0
    tf=0.5*1e-4;
else
end

if xi==0
    xi=min(Da(:,4))/10;
else
end

if xf==0
    xf=1.1*max(Da(:,2));
else
end

dxi=xi/10;dxf=xf*10;
LB=[xi dxi ti]';
UB=[xf dxf tf]';

for kDa=1:nDa
    Xre=[Da(kDa,2);Da(kDa,3);Da(kDa,4)];Dados=[freq,Xre];
    for K=1:nsol
        p1=ga(@fobj_FDS_inv,3,[],[],[],[],LB,UB);
        p1=fmincon(@fobj_FDS_inv,p1,[],[],[],[],LB,UB);
        ob=fobj_FDS_inv(p1);
        if K==1
            RES=[p1 ob]';
        else
            ww=[p1 ob]';
            RES=[RES ww];
        end
    end
    %
    % MEAN SOLUTION AND SPREADING
    md=median(RES(4,:));
    Km=0;
    for K=1:nsol
        if RES(4,K) <= md
            Km=Km+1;
            REM(1:3,Km)=RES(1:3,K);
        end 
    end
    [Min iM]=min(RES(4,:));
    pmed=RES(1:3,iM);
    pstd=std(REM')';
    Mc=fwd_FDS_inv(RES(1:3,iM));
    RMS(kDa)=Min;
    %plot_FDS_inv;
    if kDa==1
        Riv=[Da(kDa,1) RES(1:3,iM)' Dados(:,2)'];
    else
        Riv=[Riv;Da(kDa,1) RES(1:3,iM)' Dados(:,2)'];
    end
     xlf(kDa)=pmed(1);
     dx(kDa)=pmed(2);
     tau(kDa)=pmed(3);
pause(1)
XT(kDa,:)=[Xre(1) Xre(2) Xre(3) Mc(1) Mc(2) Mc(3)];
end

riv=Riv;
xhf=xlf-dx;
LFE=100*dx./xhf;
Ft=1./(1-(dx./xlf));

XO=[XT(:,1);XT(:,2);XT(:,3)]; XC=[XT(:,4);XT(:,5);XT(:,6)];
crossplot_FDS_inv

profile_FDS_inv

% MS=[XT(:,1);XT(:,2);XT(:,3)]; % observed and calculated magnetic susceptibility of all samples in the file
xlswrite('MS.xls',XT); 

PAR=[Z,XT(:,1),XT(:,2),XT(:,3),xlf,xhf,dx,tau',LFE,Ft,RMS];% sample ID, frequency independent parameters and RMS error
xlswrite('FDS_PAR.xls',PAR); 


