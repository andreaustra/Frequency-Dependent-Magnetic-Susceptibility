% ************************************************************** 
% FDS_inv - Low field frequency dependent magnetic susceptibility inversion Software 
% Tested using Matlab 8.5 Release 2015a under MacOS 
% *********************************************************** 
%           AUTHORS 
% Andrea Ustra, Carlos Mendonca, Arua Leite - 2018
% andreaustra@uol.com.br
% carlos.mendonca@iag.usp.br
% arualeite@gmail.com
% Universidade de Sao Paulo   
% Instituto de Astronomia, Geofisica e Ciencias Atmosfericas
% Departamento de Geofisica
% Sao Paulo - Brasil 
% ***********************************************************
% crossplot_FDS_inv.m is an auxiliary function in FDS_inv that plots
% the measured and calculated values of all sets of FDS data and returns 
% the correlation coefficient R^2 obtained by the linear regression 

figure
subplot(141)
plot(XT(:,1),Z,'-k');hold on;plot(XT(:,2),Z,'-r');plot(XT(:,3),Z,'-b');hold off;axis ij;
ylabel('Depth (m)');
legend('976 Hz','3904 Hz','15616 Hz');title('(a) \chi (SI)');
subplot(142)
plot(xlf,Z,'-k');hold on;plot(xhf,Z,'-r');hold off;axis ij;
legend('\chi_{lf}','\chi_{hf}');title('(b) \chi asymptotes (SI)');
subplot(143)
plot(LFE,Z,'-k');axis ij;title('(c) LFE (%)');
subplot(144)
plot(1./Ft,Z,'-k');axis ij;title('(d) F_t^{-1} ');



