% ************************************************************** 
% FDS_inv - Low field frequency dependent magnetic susceptibility inversion Software 
% Tested using Matlab 8.5 Release 2015a under MacOS 
% *********************************************************** 
%           AUTHORS 
% Andrea Ustra, Carlos Mendonca, Arua Leite - 2018
% andrea.ustra@iag.usp.br
% carlos.mendonca@iag.usp.br
% arualeite@gmail.com
% Universidade de Sao Paulo   
% Instituto de Astronomia, Geofisica e Ciencias Atmosfericas
% Departamento de Geofisica
% Sao Paulo - Brasil 
% ***********************************************************
% order.m is an auxiliary function in FDS_inv used to adjust the results
% graphic display

function n = order( val, base )
%Order of magnitude of number for specified base. Default base is 10.
%order(0.002) will return -3., order(1.3e6) will return 6.
%Author Ivar Smith

if nargin < 2
    base = 10;
end
n = floor(log(abs(val))./log(base));