% ************************************************************** 
% FDS_inv - Low field frequency dependent magnetic susceptibility inversion Software 
% Tested using Matlab 8.5 Release 2015a under MacOS 
% *********************************************************** 
%           AUTHORS 
% Andrea Ustra, Carlos Mendonca, Arua Leite - 2018
% andrea.ustra@iag.usp.br
% carlos.mendonca@iag.usp.br
% arualeite@gmail.com
% Universidade de Sao Paulo   
% Instituto de Astronomia, Geofisica e Ciencias Atmosfericas
% Departamento de Geofisica
% Sao Paulo - Brasil 
% ***********************************************************
% fobj_FDS_inv.m is an auxiliary function in FDS_inv that calculates 
% the inversion misfit by the Euclidean norm

function Q=fobj_FDS_inv(p)
global Dados
Mo=Dados(:,2);
Mc=fwd_FDS_inv(p);
Q=norm(10000*(Mo-Mc),2);
return
end
%